Place reports here as <query_id>.md. See submission.json for all 40 exact filenames. No example report counts as a system output.
